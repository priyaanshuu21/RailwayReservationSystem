from pathlib import Path
import subprocess
out=Path('/workspace/shared/railnexus-submission/assets')
def render(name,content):
 p=out/(name+'.dot');p.write_text(content)
 for ext in ['svg','png','pdf']:subprocess.run(['dot','-T'+ext,str(p),'-o',str(out/(name+'.'+ext))],check=True)
base='''graph [bgcolor="white",pad="0.25",nodesep="0.45",ranksep="0.65",dpi=180];
node [shape=box,style="rounded,filled",fillcolor="#FFF7F5",color="#B52D2A",fontname="Liberation Serif",fontsize=13,margin="0.15,0.1"];
edge [fontname="Liberation Serif",fontsize=10,color="#555555",arrowsize=0.6];'''
render('EER_Relationships','digraph EER {rankdir=LR;'+base+'''
zone [label="ZONE\\nPK zone_id\\nzone_code, zone_name"];
station [label="STATION\\nPK station_id\\nFK zone_id"];
route [label="ROUTE\\nPK route_id\\nFK origin_station, destination_station"];
stop [label="STATION_ROUTE\\nPK route_id, station_id\\nUNIQUE route_id, stop_order\\nkm_from_origin"];
train [label="TRAIN\\nPK train_id\\ntrain_no, train_type"];
tr [label="TRAIN_ROUTE\\nPK train_id, route_id\\nis_active"];
schedule [label="TRAIN_SCHEDULE\\nPK schedule_id\\nFK train_id, route_id, zone_id\\njourney_date"];
coach [label="COACH\\nPK coach_id\\nFK schedule_id\\ncoach_class, class_quota"];
seat [label="SEAT\\nPK seat_id\\nFK coach_id\\nseat_no, berth_type, status"];
person [label="PERSON / PASSENGER\\nPK person_id\\nfull_name, email"];
booking [label="BOOKING\\nPK booking_id\\nFK person_id, schedule_id\\nrequest_id UNIQUE, fare_total, status",fillcolor="#FCE4DE"];
ticket [label="TICKET\\nPK ticket_id\\nFK booking_id UNIQUE\\npnr UNIQUE, ticket_type, status",fillcolor="#FCE4DE"];
queue [label="WAITLIST_QUEUE\\nPK queue_id\\nFK ticket_id, schedule_id\\ncoach_class, position, queue_type"];
payment [label="PAYMENT\\nPK payment_id\\nFK booking_id\\nmethod, amount, status"];
refund [label="REFUND\\nPK refund_id\\nFK payment_id\\namount, status"];
audit [label="BOOKING_AUDIT\\nPK audit_id\\nFK booking_id\\nevent_type, event_time"];
outbox [label="DOMAIN_OUTBOX\\nPK event_id\\naggregate_id, payload, status"];
ann [label="STATION_ANNOUNCEMENT\\nPK announcement_id\\nFK station_id, created_by\\nmessage, active_until"];
zone->station [label="1 : N"];station->stop [label="1 : N"];route->stop [label="1 : N"];train->tr [label="1 : N"];route->tr [label="1 : N"];train->schedule [label="1 : N"];route->schedule [label="1 : N"];zone->schedule [label="1 : N"];
schedule->coach [label="1 : N"];coach->seat [label="1 : N"];person->booking [label="1 : N"];schedule->booking [label="1 : N"];booking->ticket [label="1 : 1 (application)"];ticket->queue [label="1 : 0..1 (application)"];booking->payment [label="1 : N"];payment->refund [label="1 : N"];booking->audit [label="1 : N"];audit->outbox [label="INSERT trigger",style=dashed];station->ann [label="1 : N"];person->ann [label="1 : N authors"];
}''')
render('EER_Specialization','digraph Specialization {rankdir=TB;'+base+'''
person [label="PERSON\\nPK person_id\\nperson_type: P / E"];
pd [shape=circle,label="d",width=0.3,height=0.3,fillcolor="white"];
passenger [label="PASSENGER\\nPK / FK person_id\\nid_document_number"];
employee [label="EMPLOYEE\\nPK / FK person_id\\nemployee_no, base_station_id"];
ed [shape=circle,label="d",width=0.3,height=0.3,fillcolor="white"];
tte [label="TTE_CONDUCTOR\\nPK / FK employee_id\\nzone_id, staff_id"];
sm [label="STATION_MASTER\\nPK / FK employee_id\\nstation_id, zone_id"];
za [label="ZONE_ADMIN\\nPK / FK employee_id\\nzone_id"];
sa [label="SUPER_ADMIN\\nPK / FK employee_id\\npanel_access"];
person->pd [arrowhead=none];pd->passenger [arrowhead=none];pd->employee [arrowhead=none];employee->ed [arrowhead=none];ed->tte [arrowhead=none];ed->sm [arrowhead=none];ed->za [arrowhead=none];ed->sa [arrowhead=none];
train [label="TRAIN\\nPK train_id\\ntrain_type: E / S / P / F"];
td [shape=circle,label="d",width=0.3,height=0.3,fillcolor="white"];
express [label="EXPRESS_TRAIN\\nPK / FK train_id"];superfast [label="SUPERFAST_TRAIN\\nPK / FK train_id"];ptrain [label="PASSENGER_TRAIN\\nPK / FK train_id"];freight [label="FREIGHT_TRAIN\\nPK / FK train_id"];
train->td [arrowhead=none];td->express [arrowhead=none];td->superfast [arrowhead=none];td->ptrain [arrowhead=none];td->freight [arrowhead=none];
{rank=same;person;train;}
legend [shape=note,fillcolor="#FAFAFA",label="d = disjoint subtype sets\\nSubtype primary key is also a foreign key.\\nDiscriminators and triggers reject incompatible subtype inserts.\\nSingle lines do not assert database-enforced total participation.",fontsize=11];
}''')
render('EER_Ticket_Payment','digraph Ticket {rankdir=TB;'+base+'''
t [label="TICKET\\nPK ticket_id\\nticket_type: C / R / W\\nstatus: CFM / RAC / WL / CNL"];
d [shape=circle,label="d",width=0.3,height=0.3,fillcolor="white"];
c [label="CONFIRMED_TICKET\\nPK / FK ticket_id\\ncoach_id, seat_id, berth\\nboarding_status, boarding_time"];
r [label="RAC_TICKET\\nPK / FK ticket_id\\ncoach_id, seat_id, berth"];
w [label="WAITLISTED_TICKET\\nPK / FK ticket_id\\nposition"];
t->d [arrowhead=none];d->c [arrowhead=none];d->r [arrowhead=none];d->w [arrowhead=none];
p [label="PAYMENT\\nPK payment_id\\nFK booking_id\\npayment_method: U / C / W"];
pd [shape=circle,label="d",width=0.3,height=0.3,fillcolor="white"];
u [label="UPI_PAYMENT\\nPK / FK payment_id\\nupi_handle"];
card [label="CARD_PAYMENT\\nPK / FK payment_id\\nmasked_pan, card_scheme"];
wallet [label="WALLET_PAYMENT\\nPK / FK payment_id\\nwallet_provider, wallet_txn_id"];
p->pd [arrowhead=none];pd->u [arrowhead=none];pd->card [arrowhead=none];pd->wallet [arrowhead=none];
{rank=same;t;p;}
note [shape=note,label="Active ticket subtype changes are performed by pkg_booking.\\nCancelled tickets remain in TICKET as CNL; active subtype rows are removed.\\nRAC in this application is a queue awaiting a full berth.",fontsize=11,fillcolor="#FAFAFA"];
}''')
render('Architecture','digraph Architecture {rankdir=TB;'+base+'''
u [label="Five actors\\nPassenger | TTE | Station Master | Zone Admin | Super Admin",fillcolor="#FCE4DE"];
web [label="React + TypeScript frontend\\nSeparate session per browser tab"];
api [label="Express + TypeScript API\\nJWT roles, staff scope, schedule-to-zone routing"];
oracle [label="Oracle Database / FREEPDB1\\nShared reference schema + three zone schemas\\nPL/SQL packages, constraints, triggers, views",fillcolor="#FCE4DE"];
redis [label="Redis\\nStation-list cache\\nOptional outbox pub/sub"];
mongo [label="MongoDB\\nSensor-reading document snapshots\\nTime-series initialization script"];
zones [label="RAILNEXUS_NORTH | RAILNEXUS_WEST | RAILNEXUS_SOUTH\\nBooking families fragmented by originating zone\\nShared reports aggregate through database links"];
u->web;web->api [label="HTTP / JSON"];api->oracle [label="node-oracledb"];api->redis [label="ioredis"];api->mongo [label="MongoDB driver"];oracle->zones [label="schema separation on one Oracle instance"];
}''')
render('Booking_Flow','digraph Flow {rankdir=LR;'+base+'''
start [label="Reserve ticket"];lock [label="Lock schedule\\nValidate passenger / route / class"];
cfm [label="Seat available\\nCFM + seat allocation",fillcolor="#E8F4EB"];
rac [label="Seats exhausted\\nRAC place available → RAC",fillcolor="#FFF4DA"];
wl [label="RAC full\\nWL place available → WL",fillcolor="#FCE4DE"];
audit [label="Insert booking audit\\nTrigger inserts outbox event\\nCOMMIT"];
start->lock;lock->cfm [label="yes"];lock->rac [label="no free seat"];rac->wl [label="RAC full"];cfm->audit;rac->audit;wl->audit;
}''')
print('Generated five diagram sets')

render('EER_Identity','digraph Identity {rankdir=TB;'+base+'''
person [label="PERSON\\nPK person_id\\nperson_type: P / E"];pd [shape=circle,label="d",width=0.3,height=0.3,fillcolor="white"];
p [label="PASSENGER\\nPK / FK person_id\\nID document, notification preference"];
e [label="EMPLOYEE\\nPK / FK person_id\\nemployee_no, base_station_id"];
ed [shape=circle,label="d",width=0.3,height=0.3,fillcolor="white"];
t [label="TTE_CONDUCTOR\\nPK / FK employee_id\\nzone_id, staff_id"];
s [label="STATION_MASTER\\nPK / FK employee_id\\nstation_id, zone_id"];
z [label="ZONE_ADMIN\\nPK / FK employee_id\\nzone_id"];
a [label="SUPER_ADMIN\\nPK / FK employee_id\\npanel_access"];
person->pd [arrowhead=none];pd->p [arrowhead=none];pd->e [arrowhead=none];e->ed [arrowhead=none];ed->t [arrowhead=none];ed->s [arrowhead=none];ed->z [arrowhead=none];ed->a [arrowhead=none];
}''')
render('EER_Booking','digraph Core {rankdir=TB;'+base+'''
p [label="PASSENGER\\nPK person_id"];s [label="TRAIN_SCHEDULE\\nPK schedule_id\\ntrain_id, route_id, journey_date"];
c [label="COACH\\nPK coach_id\\nFK schedule_id\\ncoach_class"];
seat [label="SEAT\\nPK seat_id\\nFK coach_id\\nseat_no, status"];
b [label="BOOKING\\nPK booking_id\\nFK person_id, schedule_id\\nfare_total, status",fillcolor="#FCE4DE"];
t [label="TICKET\\nPK ticket_id\\nFK booking_id UNIQUE\\npnr UNIQUE, status"];
q [label="WAITLIST_QUEUE\\nPK queue_id\\nFK ticket_id, schedule_id\\nposition, queue_type"];
pay [label="PAYMENT\\nPK payment_id\\nFK booking_id\\namount, status"];
p->b [label="1 : N"];s->b [label="1 : N"];s->c [label="1 : N"];c->seat [label="1 : N"];b->t [label="1 : 1 (application)"];t->q [label="1 : 0..1 (application)"];b->pay [label="1 : N"];
{rank=same;p;s;} {rank=same;b;c;} {rank=same;t;pay;seat;}
}''')
render('EER_Train','digraph Train {rankdir=TB;'+base+'''
t [label="TRAIN\nPK train_id\ntrain_type: E / S / P / F"];
d [shape=circle,label="d",width=0.3,height=0.3,fillcolor="white"];
e [label="EXPRESS_TRAIN\nPK / FK train_id"];
s [label="SUPERFAST_TRAIN\nPK / FK train_id"];
p [label="PASSENGER_TRAIN\nPK / FK train_id"];
f [label="FREIGHT_TRAIN\nPK / FK train_id"];
t->d [arrowhead=none];d->e [arrowhead=none];d->s [arrowhead=none];d->p [arrowhead=none];d->f [arrowhead=none];
}''')
